
import React from 'react';

const CampaignHistory = () => {
  return <div>Campaign History Component</div>;
};

export default CampaignHistory;
