
import React from 'react';

const MessageSend = () => {
  return <div>Message Send Component</div>;
};

export default MessageSend;
