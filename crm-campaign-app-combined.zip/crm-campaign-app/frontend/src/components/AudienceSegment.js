
import React, { useState } from 'react';
import axios from 'axios';

const AudienceSegment = () => {
  const [criteria, setCriteria] = useState('');

  const handleCreateSegment = async () => {
    await axios.post('/api/audience', { criteria });
  };

  return (
    <div>
      <input type="text" value={criteria} onChange={(e) => setCriteria(e.target.value)} />
      <button onClick={handleCreateSegment}>Create Segment</button>
    </div>
  );
};

export default AudienceSegment;
