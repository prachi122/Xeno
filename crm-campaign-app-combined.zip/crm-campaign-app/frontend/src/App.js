
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import AudienceSegment from './components/AudienceSegment';
import CampaignHistory from './components/CampaignHistory';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<AudienceSegment />} />
        <Route path="/campaign-history" element={<CampaignHistory />} />
      </Routes>
    </Router>
  );
}

export default App;
