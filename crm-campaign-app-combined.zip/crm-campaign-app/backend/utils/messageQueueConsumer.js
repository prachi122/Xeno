
// Dummy Consumer Setup for Queue Processing
